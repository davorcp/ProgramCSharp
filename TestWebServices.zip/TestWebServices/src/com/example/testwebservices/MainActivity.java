package com.example.testwebservices;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);  // Set up GUI
        
        final EditText addressfield = (EditText) findViewById(R.id.address);  // Reference edit field
        final Button launchmapbtn = (Button) findViewById(R.id.launchmap);  // Reference search button
        launchmapbtn.setOnClickListener(new OnClickListener(){	
				public void onClick(View v) { 
					try {
						String address = addressfield.getText().toString(); // Get address
						address = address.replace(' ', '+');
						Intent geoIntent = new Intent (android.content.Intent.ACTION_VIEW, Uri.parse ("geo:0,0?q=" + address)); // Prepare intent
						startActivity(geoIntent);	// Initiate lookup
					} catch (Exception e){
						
						
					}	
			}
		});
    }
}